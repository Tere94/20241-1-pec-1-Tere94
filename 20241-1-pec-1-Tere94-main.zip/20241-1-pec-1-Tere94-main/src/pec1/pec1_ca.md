# Respostes a les preguntes teòriques

## Exercici T1

* (1,5 punts) T1.1 (1p) Descriu cada una de les comandes que ha realitzat el desenvolupador `Dev1` i valora si són correctes/incorrectes o necessàries/innecessàries.
  
* (1,5 punts) T1.2 Descriu cadascuna de les comandes que ha realitzat el desenvolupador `Dev2` i valora si són correctes/incorrectes o necessàries/innecessàries.

## Exercici T2

* (2 punts) T2.1 Quins commits són considerats a la branca `developer-1`?

* (2 punts) T2.2 Quan es fa el _merge_ de la branca `developer-1` a la branca `main` i es crea el commit `c5`, quins canvis s'incorporen a la branca `main`? (has d'indicar quins commits contribueixen a fer canvis a la branca `main`).
