function ex1(value) {
    if (value >= 2000 && value <= 2020) {
        return true;
    } else {
        return false;
    }
}

 
function ex2(times) { 
    return (times/5)-9;
}
module.exports = {ex1, ex2}
